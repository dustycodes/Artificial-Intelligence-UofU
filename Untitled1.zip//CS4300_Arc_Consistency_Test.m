function data = CS4300_Arc_Consistency_Test()
% CS4300_Arc_Consistency_Test - Runs AC1 & AC3 and takes statistics.
% On input:
% arguments:
% On output:
% data (1200x5 array): N, r1, r2, t1, t2
% Call:
% Author:
% Dusty Argyle
% UU
% Fall 2016
% 
P = 'CS4300_Arc_Consistency_Predicate';
data = zeros(1200, 5);
iter = 1;

for N=4:10
   data(iter, 1) = N;
   G = ~eye(N,N);
   
   for p = 0:0.2:1
       for t=1:200
          D = rand(N,N) < p;
          
          tic;
          D1 = CS4300_AC3(G, D, P);
          t1 = toc;
          data(iter, 2) = numel(find(D)) - numel(find(D1));
          data(iter, 4) = t1;
          
          tic;
          D2 = CS4300_AC1(G, D, P);
          t2 = toc;
          data(iter, 3) = numel(find(D)) - numel(find(D2));
          data(iter,5) = t2;
       end
   end
end
end