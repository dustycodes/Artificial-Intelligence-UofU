function [changed, D] = CS4300_Arc_Consistency_Revised(D, P, arc)
% CS4300_Arc_Consistency_Revised - Checks the domain if the arc is
% consistent. Returns the revised domain and if the domain was revised.
% On input:
% D (nxm array): m domain values for each of n nodes
% P (string): predicate function name; P(i,a,j,b) takes as
% arc (2x1 vector): x, y component of the arc we are checking
% On output:
% changed (1 or 0): 1 if the domain was revised, otherwise 0
% D (nxm array): revised m domain values for each of n nodes
% Call: 
% D = [0,0,0;1,0,1;1,0,0];
% P = 'CS4300_Arc_Consistency_Predicate';
% arc = [1, 2];
% [changed, D] = CS4300_Arc_Consistency_Revised(D, P, arc)
% Author:
% Dusty Argyle
% UU
% Fall 2016
% 
    [N,M] = size(D);
    i = arc(1);
    j = arc(2);
    changed = 0;
    counter = 1;
    
    found = 0;
    for x = 1:N
        for y = 1:N
            if D(x,y) == 1
                found = feval(P, i, j, x, y);
                if found == 1
                    break
                end
            end
        end
        if found == 0
            counter = counter + 1;
        end
    end
    if counter == N
    	D(i,1:N) = 0;
    	changed = 1;
    end
end